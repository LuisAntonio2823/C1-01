package com.upchiapas.SitioTaxi;

import com.upchiapas.SitioTaxi.Models.Chofer;
import com.upchiapas.SitioTaxi.Models.Vehiculo;

import java.util.Scanner;

public class Main {
    private static Chofer[] listaChofers = new Chofer[5];
    private static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) {
        byte opcion;

        do {
            //JOptionPane.showMessageDialog(null, "UNIVERSIDAD POLITECNICA DE CHIAPAS");
            System.out.println("UNIVERSIDAD POLITECNICA DE CHIAPAS");
            System.out.println("1. Agregar Chofer");
            System.out.println("2. Agregar vehiculo");
            System.out.println("3. Imprimir Ganancias de Unidades: ");
            System.out.println("4. Imprimir en que unidad le toca al chofer: ");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = teclado.nextByte();
            switch (opcion){
                case 1: addPersona(); break;
                case 2: addVehiculo(); break;
                case 3: imprimirPersonas();break;
            }
        } while (opcion <5);

    }

    public static void addPersona() {
        short id;
        String nombre;
        short it;
        String licencia;
        byte numeroVehiculos;
        Chofer chofer;

        // Sección para capturar datos
        System.out.print("Ingresa el ID: ");
        id = teclado.nextShort();
        teclado.nextLine();
        System.out.print("Ingresa el nombre: ");
        nombre = teclado.nextLine();
        System.out.print("Vehiculo a registrar: ");
        numeroVehiculos = teclado.nextByte();
        System.out.print("Ingrese el numero de su Tarjeton: ");
        it = teclado.nextShort();
        teclado.nextLine();
        System.out.print("Ingrese su licencia: ");
        licencia = teclado.nextLine();

        // Sección para almacenar datos
        chofer = new Chofer(numeroVehiculos);
        chofer.setId(id);
        chofer.setNombre(nombre);
        chofer.setit(it);
        chofer.setlicencia(licencia);


        System.out.println("Valor de persona: " + chofer);
        byte indice = 0;
        while (listaChofers[indice] != null)
            indice++;
        listaChofers[indice] = chofer;

    }
    public static void addVehiculo() {
        String marca;
        String model;
        Short TM;
        String placa;


        //Captura de Datos
        System.out.print("Ingrese la Tarjeta de circulacion: ");
        TM= teclado.nextShort();
        teclado.nextLine();
        System.out.print("Ingrese el Modelo del vehiculo: ");
        model= teclado.nextLine();
        System.out.print("Ingrese la Marca del Vehiculo: ");
        marca = teclado.nextLine();
        System.out.print("Ingrese la placa del Vehiculo: ");
        placa= teclado.nextLine();
    }

    public static void imprimirPersonas() {}
}
