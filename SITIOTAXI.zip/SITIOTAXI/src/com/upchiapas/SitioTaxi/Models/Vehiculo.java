package com.upchiapas.SitioTaxi.Models;

public class Vehiculo {
    private String marca;
    private String model;
    private int placa;
    private Short TM;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return model;
    }

    public void setModelo(short modelo) {
        this.model = model;
    }

    public short getTM(){  return TM; }

    public void setTM(Short TM) {
        this.TM = TM;
    }

    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }
}
