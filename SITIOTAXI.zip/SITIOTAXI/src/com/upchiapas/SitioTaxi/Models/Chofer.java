package com.upchiapas.SitioTaxi.Models;

public class Chofer {
    private short id;
    private String nombre;
    private String rol;
    private Vehiculo[] listaVehiculos;
    private short it;
    private String licencia;
    public Chofer(byte numeroVehiculos){
        listaVehiculos = new Vehiculo[numeroVehiculos];
    }

    public short getId() {
        return id;
    }

    public void setId(short id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public short getIt(){ return  it;}

    public void setit(short it){this.it= it;}

    public void setlicencia(String licencia){this.licencia=licencia;}

}
